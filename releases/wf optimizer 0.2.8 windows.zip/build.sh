#!/bin/bash
set -e
cargo build --release