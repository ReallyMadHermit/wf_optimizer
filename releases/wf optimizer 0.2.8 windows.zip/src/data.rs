pub const GUN_DATA: &'static str = include_str!("data/gun_data.csv");
pub const GUN_MODS: &'static str = include_str!("data/gun_mods.csv");
pub const GUN_ARCANES: &'static str = include_str!("data/gun_arcanes.csv");